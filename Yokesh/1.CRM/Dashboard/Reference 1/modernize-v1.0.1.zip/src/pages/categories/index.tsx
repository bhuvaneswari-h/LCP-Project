const CategoriesPage = () => {
  return (
    <div>
      <h1>Categories Page </h1>
    </div>
  );
};

export default CategoriesPage;
