const ProductsPage = () => {
  return (
    <div>
      <h1>Products Page</h1>
    </div>
  );
};

export default ProductsPage;
