const CouponsPage = () => {
  return (
    <div>
      <h1>Coupons Page</h1>
    </div>
  );
};

export default CouponsPage;
