const ReportsPage = () => {
  return (
    <div>
      <h1>Reports Page</h1>
    </div>
  );
};

export default ReportsPage;
