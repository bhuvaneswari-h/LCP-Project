const InboxPage = () => {
  return (
    <div>
      <h1>Inbox Page</h1>
    </div>
  );
};

export default InboxPage;
