const OrdersPage = () => {
  return (
    <div>
      <h1>Orders Page</h1>
    </div>
  );
};

export default OrdersPage;
